package com.company;

public enum AdvancedOperations {
    SUMMATION,
    SUBTRACT,
    MULTIPLICATION,
    DIVISION,
    REMAINING,
    Log,
    Ln,
    Exp,
    Pow,
    pi,
    nrp,
    Sin,
    Cos,
    Tan,
    Cot
}
