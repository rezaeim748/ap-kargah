package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Make two kinds of calculator
 */
public class TabbedPaneExample  {
    private JFrame calcFrame;
    private JTextField tf1 ;
    private JTextField tf2 ;
    private PrimitiveOperations pOperation ;
    private AdvancedOperations aOperation ;
    private Double result ;
    private String resultStr ;
    JButton btnS ;
    JButton btnT ;





    TabbedPaneExample(){
        calcFrame=new JFrame();
        tf1 = new JTextField();
        tf2 = new JTextField();
        result = 0.0 ;
        calcFrame.setTitle("AUT Calculator");
        calcFrame.setSize(400,400);
        calcFrame.setLocation(50, 100);
        calcFrame.setLayout(null);
        calcFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        JTabbedPane tp=new JTabbedPane();
        tp.setBounds(10,10,300,300);
        addKeysAndScreen(tp);
        keyHandling();
        addMenu();


        calcFrame.setVisible(true);

    }

    public void updateCal (){
        calcFrame.setVisible(true);
    }

    public void addActionListenerToACB (JButton btn, JTextField tf){
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tf.setText("");
            }
        });
    }

    public void addActionListenerToAdvancedCalEquationB (JButton btn){
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (resultStr != null){
                    result = Double.parseDouble(resultStr) ;
                }
                Double secondNumber = null ;
                if (tf2.getText() != null) {
                    secondNumber = Double.parseDouble(tf2.getText());
                }
                if ((secondNumber != null) && (resultStr != null)){
                    switch (aOperation) {
                        case SUMMATION:
                            result = result + secondNumber ;
                            tf2.setText((int)Math.round(result) + "");
                            break ;
                        case SUBTRACT:
                            result = result - secondNumber ;
                            tf2.setText((int)Math.round(result) + "");
                            break ;
                        case MULTIPLICATION:
                            result = result * secondNumber ;
                            tf2.setText((int)Math.round(result) + "");
                            break ;
                        case DIVISION:
                            result = result / secondNumber ;
                            tf2.setText((int)Math.round(result) + "");
                            break ;
                        case REMAINING:
                            result = result % secondNumber ;
                            tf2.setText((int)Math.round(result) + "");
                            break ;
                        case Pow:
                            result = Math.pow(result, secondNumber) ;
                            tf2.setText((int)Math.round(result) + "");
                            break ;
                        default:
                            break ;
                    }
                }
            }
        });
    }

    public void addActionListenerToRegularCalEquationB (JButton btn){
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (resultStr != null){
                    result = Double.parseDouble(resultStr) ;
                }
                Double secondNumber = null ;
                if (tf1.getText() != null) {
                    secondNumber = Double.parseDouble(tf1.getText());
                }
                if ((secondNumber != null) && (resultStr != null)){
                    switch (pOperation) {
                        case SUMMATION:
                            result = result + secondNumber ;
                            tf1.setText((int)Math.round(result) + "");
                            break ;
                        case SUBTRACT:
                            result = result - secondNumber ;
                            tf1.setText((int)Math.round(result) + "");
                            break ;
                        case MULTIPLICATION:
                            result = result * secondNumber ;
                            tf1.setText((int)Math.round(result) + "");
                            break ;
                        case DIVISION:
                            result = result / secondNumber ;
                            tf1.setText((int)Math.round(result) + "");
                            break ;
                        case REMAINING:
                            result = result % secondNumber ;
                            tf1.setText((int)Math.round(result) + "");
                            break ;
                        default:
                            break ;
                    }
                }
            }
        });
    }

    public void addActionListenerToNumbers (JButton btn, JTextField tf){
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed (ActionEvent e){
                JButton t = (JButton) e.getSource() ;
                for (int i = 0; i <= 9; i++){
                    if (t.getText().contains("" + i)){
                        String temp = tf.getText() ;
                        temp += i ;
                        tf.setText(temp) ;
                    }
                }
            }
        });
    }

    public void addActionListenerToControls (JButton btn){
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton button = (JButton) e.getSource() ;
                switch (button.getText()) {
                    case "shift":
                        if (btnS.getText().equals("sin")) {
                            btnS.setText("cos");
                            btnT.setText("cot");
                        }
                        else {
                            btnS.setText("sin");
                            btnT.setText("tan");
                        }
                        updateCal();
                        break ;
                    case "DEL":
                        if (tf2.getText() != null){
                            String str = tf2.getText() ;
                            tf2.setText(str.substring(0, str.length() - 1)) ;
                        }
                        break ;
                    case "AC":
                        tf2.setText("") ;
                        break ;
                    default :
                        break ;
                }
            }
        });
    }

    public void addActionListenerToAdvancedO (JButton btn){
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton button = (JButton) e.getSource() ;
                switch (button.getText()){
                    case "+" :
                        aOperation = AdvancedOperations.SUMMATION ;
                        resultStr = tf2.getText() ;
                        tf2.setText("") ;
                        break ;
                    case "-" :
                        aOperation = AdvancedOperations.SUBTRACT ;
                        resultStr = tf2.getText() ;
                        tf2.setText("") ;
                        break ;
                    case "*" :
                        aOperation = AdvancedOperations.MULTIPLICATION ;
                        resultStr = tf2.getText() ;
                        tf2.setText("") ;
                        break ;
                    case "/" :
                        aOperation = AdvancedOperations.DIVISION ;
                        resultStr = tf2.getText() ;
                        tf2.setText("") ;
                        break ;
                    case "%" :
                        aOperation = AdvancedOperations.REMAINING ;
                        resultStr = tf2.getText() ;
                        tf2.setText("") ;
                        break ;
                    case "log" :
                        aOperation = AdvancedOperations.Log ;
                        resultStr = tf2.getText() ;
                        if (resultStr != null) {
                            result = Double.parseDouble(resultStr);
                            result = Math.log10(result) ;
                            tf2.setText(result + "");
                        }
                        break ;
                    case "ln" :
                        aOperation = AdvancedOperations.Ln ;
                        resultStr = tf2.getText() ;
                        if (resultStr != null) {
                            result = Double.parseDouble(resultStr);
                            result = Math.log(result);
                            tf2.setText(result + "");
                        }
                        break ;
                    case "exp" :
                        aOperation = AdvancedOperations.Exp ;
                        resultStr = tf2.getText() ;
                        if (resultStr != null) {
                            result = Double.parseDouble(resultStr);
                            result = Math.exp(result) ;
                            tf2.setText(result + "");
                        }
                        break ;
                    case "pow" :
                        aOperation = AdvancedOperations.Pow ;
                        resultStr = tf2.getText() ;
                        tf2.setText("") ;
                        break ;
                    case "pi" :
                        aOperation = AdvancedOperations.pi ;
                        break ;
                    case "nrp" :
                        aOperation = AdvancedOperations.nrp ;
                        break ;
                    case "sin" :
                        aOperation = AdvancedOperations.Sin ;
                        resultStr = tf2.getText() ;
                        if (resultStr != null) {
                            result = Double.parseDouble(resultStr);
                            result = Math.sin(result) ;
                            tf2.setText(result + "");
                        }
                        break ;
                    case "cos" :
                        aOperation = AdvancedOperations.Cos ;
                        resultStr = tf2.getText() ;
                        if (resultStr != null) {
                            result = Double.parseDouble(resultStr);
                            result = Math.cos(result) ;
                            tf2.setText(result + "");
                        }
                        break ;
                    case "tan" :
                        aOperation = AdvancedOperations.Tan ;
                        resultStr = tf2.getText() ;
                        if (resultStr != null) {
                            result = Double.parseDouble(resultStr);
                            result = Math.tan(result) ;
                            tf2.setText(result + "");
                        }
                        break ;
                    case "cot" :
                        aOperation = AdvancedOperations.Cot ;
                        resultStr = tf2.getText() ;
                        if (resultStr != null) {
                            result = Double.parseDouble(resultStr);
                            result = 1.0 / Math.tan(result) ;
                            tf2.setText(result + "");
                        }
                        break ;
                    default :
                        break ;
                }

            }
        });
    }


    public void addActionListerToPrimitiveO (JButton btn){
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton button = (JButton) e.getSource() ;
                switch (button.getText()){
                    case "+" :
                        pOperation = PrimitiveOperations.SUMMATION ;
                        resultStr = tf1.getText() ;
                        tf1.setText("") ;
                        break ;
                    case "-" :
                        pOperation = PrimitiveOperations.SUBTRACT ;
                        resultStr = tf1.getText() ;
                        tf1.setText("") ;
                        break ;
                    case "*" :
                        pOperation = PrimitiveOperations.MULTIPLICATION ;
                        resultStr = tf1.getText() ;
                        tf1.setText("") ;
                        break ;
                    case "/" :
                        pOperation = PrimitiveOperations.DIVISION ;
                        resultStr = tf1.getText() ;
                        tf1.setText("") ;
                        break ;
                    case "%" :
                        pOperation = PrimitiveOperations.REMAINING ;
                        resultStr = tf1.getText() ;
                        tf1.setText("") ;
                        break ;
                    default :
                        break ;
                }
                tf1.setText("") ;
            }
        });
    }

    /**
     * Add buttons to regular calculator
     * @param p The JPanel which contains calculator buttons
     */
    public void addButtonsToRegularCal (JPanel p){
        JButton btn = new JButton();
        btn.setText("1");
        addActionListenerToNumbers(btn, tf1);
        p.add(btn);

        btn = new JButton();
        btn.setText("2");
        addActionListenerToNumbers(btn, tf1);
        p.add(btn);

        btn = new JButton();
        btn.setText("3");
        addActionListenerToNumbers(btn, tf1);
        p.add(btn);

        btn = new JButton();
        btn.setText("*");
        addActionListerToPrimitiveO(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("4");
        addActionListenerToNumbers(btn, tf1);
        p.add(btn);

        btn = new JButton();
        btn.setText("5");
        addActionListenerToNumbers(btn, tf1);
        p.add(btn);

        btn = new JButton();
        btn.setText("6");
        addActionListenerToNumbers(btn, tf1);
        p.add(btn);

        btn = new JButton();
        btn.setText("/");
        addActionListerToPrimitiveO(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("7");
        addActionListenerToNumbers(btn, tf1);
        p.add(btn);

        btn = new JButton();
        btn.setText("8");
        addActionListenerToNumbers(btn, tf1);
        p.add(btn);

        btn = new JButton();
        btn.setText("9");
        addActionListenerToNumbers(btn, tf1);
        p.add(btn);

        btn = new JButton();
        btn.setText("%");
        addActionListerToPrimitiveO(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("+");
        addActionListerToPrimitiveO(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("0");
        addActionListenerToNumbers(btn, tf1);
        p.add(btn);

        btn = new JButton();
        btn.setText("-");
        addActionListerToPrimitiveO(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("=");
        addActionListenerToRegularCalEquationB(btn);
        p.add(btn);
    }

    /**
     * Add buttons to advanced calculator
     * @param p The JPanel which contains calculator buttons
     */
    public void addButtonsToAdvancedCal (JPanel p){
        JButton btn = new JButton();
        btn.setText("log");
        addActionListenerToAdvancedO(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("ln");
        addActionListenerToAdvancedO(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("exp");
        addActionListenerToAdvancedO(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("pow");
        addActionListenerToAdvancedO(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("pi");
        addActionListenerToAdvancedO(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("nrp");
        addActionListenerToAdvancedO(btn);
        p.add(btn);

        btnS = new JButton();
        btnS.setText("sin");
        addActionListenerToAdvancedO(btnS);
        p.add(btnS);

        btnT = new JButton();
        btnT.setText("tan");
        addActionListenerToAdvancedO(btnT);
        p.add(btnT);

        btn = new JButton();
        btn.setText("shift");
        addActionListenerToControls(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("");
        p.add(btn);

        btn = new JButton();
        btn.setText("DEL");
        addActionListenerToControls(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("AC");
        addActionListenerToControls(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("1");
        addActionListenerToNumbers(btn, tf2);
        p.add(btn);

        btn = new JButton();
        btn.setText("2");
        addActionListenerToNumbers(btn, tf2);
        p.add(btn);

        btn = new JButton();
        btn.setText("3");
        addActionListenerToNumbers(btn, tf2);
        p.add(btn);

        btn = new JButton();
        btn.setText("*");
        addActionListenerToAdvancedO(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("4");
        addActionListenerToNumbers(btn, tf2);
        p.add(btn);

        btn = new JButton();
        btn.setText("5");
        addActionListenerToNumbers(btn, tf2);
        p.add(btn);

        btn = new JButton();
        btn.setText("6");
        addActionListenerToNumbers(btn, tf2);
        p.add(btn);

        btn = new JButton();
        btn.setText("/");
        addActionListenerToAdvancedO(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("7");
        addActionListenerToNumbers(btn, tf2);
        p.add(btn);

        btn = new JButton();
        btn.setText("8");
        addActionListenerToNumbers(btn, tf2);
        p.add(btn);

        btn = new JButton();
        btn.setText("9");
        addActionListenerToNumbers(btn, tf2);
        p.add(btn);

        btn = new JButton();
        btn.setText("%");
        addActionListenerToAdvancedO(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("+");
        addActionListenerToAdvancedO(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("0");
        addActionListenerToNumbers(btn, tf2);
        p.add(btn);

        btn = new JButton();
        btn.setText("-");
        addActionListenerToAdvancedO(btn);
        p.add(btn);

        btn = new JButton();
        btn.setText("=");
        addActionListenerToAdvancedCalEquationB(btn);
        p.add(btn);
    }

    public void addKeysAndScreen (JTabbedPane tp){
        JPanel pb1 = new JPanel() ;
        pb1.setLayout(new BorderLayout());
        JButton btn = new JButton() ;
        btn.setText("AC");
        addActionListenerToACB(btn, tf1);
        pb1.add(tf1, BorderLayout.CENTER) ;
        pb1.add(btn, BorderLayout.EAST) ;

        JPanel pg1=new JPanel();
        pg1.setLayout(new GridLayout(4, 4));
        addButtonsToRegularCal(pg1);
        pb1.add(pg1, BorderLayout.SOUTH) ;


        JPanel pb2 = new JPanel() ;
        pb2.setLayout(new BorderLayout());
        pb2.add(tf2, BorderLayout.CENTER) ;

        JPanel pg2 = new JPanel() ;
        pg2.setLayout(new GridLayout(7, 4));
        addButtonsToAdvancedCal(pg2);
        pb2.add(pg2, BorderLayout.SOUTH) ;


        tp.add("regular",pb1);
        tp.add("advanced",pb2);

        calcFrame.add(tp);

    }


    public void keyHandling (){

        calcFrame.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ESCAPE){
                    System.exit(0);
                }
            }
        });
        calcFrame.setFocusable(true);
    }


    public void addMenu (){

        JMenuBar jmb = new JMenuBar();
        calcFrame.setJMenuBar(jmb);

        JMenu m1 = new JMenu("Menu");
        m1.setMnemonic('M');
        jmb.add(m1);

        JMenuItem item1 = new JMenuItem("Exit");
        JMenuItem item2 = new JMenuItem("Copy cal1");
        JMenuItem item3 = new JMenuItem("Copy cal2");

        item1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        item2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String content = tf1.getText() ;
            }
        });
        item3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String content = tf2.getText() ;
            }
        });

        item1.setMnemonic('X');
        item2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.ALT_MASK));
        item3.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_T, ActionEvent.CTRL_MASK));

        m1.add(item1);
        m1.add(item2);
        m1.add(item3);

        jmb.add(m1);

    }





}

