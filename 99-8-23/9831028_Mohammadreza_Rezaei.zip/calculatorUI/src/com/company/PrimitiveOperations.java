package com.company;

public enum PrimitiveOperations {
    SUMMATION,
    SUBTRACT,
    MULTIPLICATION,
    DIVISION,
    REMAINING
}
