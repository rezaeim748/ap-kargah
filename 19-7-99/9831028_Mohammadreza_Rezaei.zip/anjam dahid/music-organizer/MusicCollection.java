import java.util.ArrayList;

/**
 * A class to hold details of audio files.
 *
 * @author David J. Barnes and Michael K�lling
 * @version 2011.07.31
 */
public class MusicCollection {
    // An ArrayList for storing the file names of music files.
    private ArrayList<String> files;
    private ArrayList<String> favoriteFiles;
    private ArrayList<String> singers;
    private ArrayList<String> publishDates;

    // A player for the music files.
    private MusicPlayer player;

    /**
     * Create a MusicCollection
     */
    public MusicCollection() {
        files = new ArrayList<>();
        favoriteFiles = new ArrayList<>();
        singers = new ArrayList<>();
        publishDates = new ArrayList<>();
        player = new MusicPlayer();
    }

    /**
     * Add a file to the collection.
     *
     * @param fileName The file to be added.
     */
    public void addFile(String fileName, String singer, String publishDate) {
        files.add(fileName);
        singers.add(singer);
        publishDates.add(publishDate);
    }

    /**
     * Add a file to the favorite files collection.
     *
     * @param fileName The name of the file to be added.
     */
    public void addFavoriteFile(String fileName) {
        favoriteFiles.add(fileName);
    }


    /**
     * Return the number of files in the collection.
     *
     * @return The number of files in the collection.
     */
    public int getNumberOfFiles() {
        return files.size();
    }

    /**
     * List a file from the collection.
     *
     * @param index The index of the file to be listed.
     */
    public void listFile(int index) {

    }

    /**
     * Show a list of all the files in the collection.
     */
    public void listAllFiles()
    {
        for (String s : files)
        {
            System.out.println(s);
        }
    }

    public void listAllFavoriteFiles()
    {
        for (String s : favoriteFiles)
        {
            System.out.println(s) ;
        }
    }

    /**
     * Remove a file from the collection.
     * @param index The index of the file to be removed.
     */
    public void removeFile(int index)
    {
        files.remove(index) ;
        singers.remove(index) ;
        publishDates.remove(index) ;
    }

    /**
     * Remove a file from the favorite files collection.
     * @param fileName The name of the file to be removed.
     */
    public void removeFavoriteFile (String fileName)
    {
        favoriteFiles.remove(fileName) ;
    }

    /**
     * Start playing a file in the collection.
     * Use stopPlaying() to stop it playing.
     * @param index The index of the file to be played.
     */
    public void startPlaying(int index)
    {
        player.startPlaying(files.get(index)) ;
    }

    /**
     * Stop the player.
     */
    public void stopPlaying()
    {
        player.stop() ;
    }


    /**
     * Determine whether the given index is valid for the collection.
     * Print an error message if it is not.
     * @param index The index to be checked.
     * @return true if the index is valid, false otherwise.
     */
    private boolean validIndex(int index)
    {
        // The return value.
        // Set according to whether the index is valid or not.
        if ((index >= files.size()) || (index < 0))
        {
            return false ;
        }
        else
            return true ;

    }

    public void validFile (String fileName)
    {
        for (int i = 0; i < files.size(); i++)
        {
            if (files.get(i).equals(fileName))
            {
                System.out.println("file name : " + fileName) ;
                System.out.println("singer : " + singers.get(i)) ;
                System.out.println("publish date : " + publishDates.get(i)) ;
                return ;
            }
        }
        System.out.println("There is no file such as " + fileName) ;
    }


}