package com.company;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;


public class Client extends Thread {

    public Client(){
        init();
        start();
    }


    InputStream in = null ;
    OutputStream out = null ;


    public void init(){
        try {
            Scanner reader = new Scanner(System.in) ;

            Socket s = new Socket("192.168.1.104" , 20000 );
            in = new DataInputStream(new BufferedInputStream(s.getInputStream())) ;
            out = (s.getOutputStream()) ;

            String temp = "" ;
            while (!temp.equals("over")) {
                temp = reader.nextLine();
                byte[] r = temp.getBytes("UTF-8");
                out.write(r);
            }
            //s.close();

        } catch (IOException ex) {
            System.err.println(ex.toString());
        }
    }



    public void run(){
        while(true){
            try {
                int a = in.available() ;
                if(a > 0){
                    byte [] e = new byte[a]  ;
                    in.read(e) ;
                    String s = new String(e, "UTF-8") ;
                    System.out.println("Reply = " + s );
                    System.exit(0) ;

                }
            } catch (IOException ex) {
                System.err.println(ex.toString());
            }
        }
    }






}
