package com.company;

public class Engine extends Thread {

    private String name ;

    public Engine(String name){
        this.name = name ;
        start();
    }



    public void run(){
        int counter = 0 ;
        while(true){
            System.out.println(name + "  :  " + counter );
            counter ++ ;

            try {
                Thread.sleep(50);
            } catch (InterruptedException ex) {

            }
        }
    }

}
