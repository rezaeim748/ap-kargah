package com.company;

public class Main {



    public static void main(String[] args) {



        //Server server = new Server();
        Client c = new Client();



    }

}