package com.company;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.sql.DataTruncation;


public class Worker extends Thread {

    Socket channel = null ;
    String text = "" ;
    int clientNumber = 0 ;

    public Worker(Socket s, int clientNumber){
        channel = s ;
        this.clientNumber = clientNumber ;
        start();
    }


    public void run(){
        InputStream in ;
        try {
            in = new DataInputStream( new BufferedInputStream( channel.getInputStream() ) );
            OutputStream out = (channel.getOutputStream());

            while(true){
                int a=in.available();

                if(a > 0){
                    byte [] array = new byte[a] ;
                    in.read(array) ;
                    String s = new String(array, "UTF-8") ;
                    if (s.equals("over")){
                        byte[] bytes = text.getBytes("UTF-8");
                        out.write(bytes);
                    }
                    text += s ;
                    System.out.println(" i get '" + s + "' from client " + clientNumber) ;
                }
            }

        } catch (IOException ex) {
            System.err.println(ex.toString());
        }

    }


}
