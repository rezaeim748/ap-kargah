package com.company;

public class Engine2 implements Runnable {

    private String name ;
    public Engine2(String name){
        this.name = name ;
        Thread t = new Thread(this);
        t.start();
    }



    public void run(){
        int counter = 0 ;
        while(true){
            System.out.println(name + "  :  " + counter);
            counter ++ ;
            try {
                Thread.sleep(50);
            } catch (InterruptedException ex) {
                System.err.println(ex.toString());
            }
        }
    }


}
