package com.company;

public class Main {

    public static void main(String[] args) {
        // Creating three students.
        Student std1 = new Student("Ehsan","Edalat", "9031066");
        Student std2 = new Student("Seyed", "Ahmadpanah", "9031806");
        Student std3 = new Student("Ahmad", "Asadi", "9031054");

        // Setting a new grade for std1.
        std1.print();
        std1.setGrade(15);
        std1.print();
        System.out.println() ;

        // Setting a new grade for std2.
        std2.print();
        std2.setGrade(11);
        std2.print();
        System.out.println() ;

        // Setting a new name for std3.
        std3.print();
        std3.setFirstName("HamidReza");
        std3.print();
        System.out.println() ;



        // Adding the created students to the lab.
        Lab lab = new Lab(30, "shanbe") ;
        lab.enrollStudent(std1) ;
        lab.enrollStudent(std2) ;
        lab.enrollStudent(std3) ;

        // Calculating the average of the students grades.
        lab.calculateAvg() ;

        // Printing the students information.
        lab.print() ;

    }
}
