package com.company;

/**
 * A class to store students information.
 *
 * @author Mohammadreza Rezaei
 * @version 0.0
 */
 public class Lab {
     // An array of the students.
     private Student[] students;
     // The average of the students grades.
     private int avg;
     // The day which is the lab on.
     private String day;
     // The capacity of the lab.
     private int capacity;
     // The size of the lab at every moment.
     private int currentSize ;

    /**
     * Perform any initialization that is required for the
     * lab.
     * @param cap The capacity of the lab.
     * @param d The day that the lab is on.
     */
     public Lab(int cap, String d) {

         capacity = cap ;
         day = d ;
         students = new Student[cap] ;
         currentSize = 0 ;
     }

    /**
     * Add a student to the lab.
     * @param std The student.
     */
     public void enrollStudent(Student std) {
         if (currentSize < capacity) {
             students[currentSize] = std ;
             currentSize++ ;
         }
         else {
             System.out.println("Lab is full!!!");
         }
     }

    /**
     * Print students information and the average
     * of their grades.
     */
    public void print() {

         for (int i = 0; i < currentSize; i++){
             students[i].print() ;
         }
         System.out.println("average is: " + avg) ;
     }

    /**
     * Return the student.
     * @return a student.
     */
     public Student[] getStudents() {
         return students ;
     }

    /**
     * Set the given array to the students array.
     * @param students The array to maintain students.
     */
     public void setStudents(Student[] students) {
         this.students = students ;
     }

    /**
     * Return the average of students grades.
     * @return an integer which is the average of
     * students grades.
     */
     public int getAvg() {
        return avg ;
     }

    /**
     * Calculate the average of the students grades.
     */
    public void calculateAvg() {
         float sum = 0;
         float average ;
         // int i ;
         for (int i = 0; i < currentSize; i++){
             sum += students[i].getGrade() ;
         }
         average = sum / currentSize ;
         avg = (int) average ;
     }

    /**
     * Return the day which is the lab on.
     * @return a string which is the the day that the lab on.
     */
     public String getDay() {

         return day ;
     }

    /**
     * Set the given day to the day.
     * @param day The day that the lab is on.
     */
     public void setDay(String day) {
         this.day = day ;
     }

    /**
     * Return the capacity of the lab.
     * @return an integer which is the capacity of the lab.
     */
     public int getCapacity() {
         return capacity ;
     }

    /**
     * Set the given number to the capacity.
     * @param capacity The capacity of the lab.
     */
     public void setCapacity(int capacity) {
         this.capacity = capacity ;
     }
 }