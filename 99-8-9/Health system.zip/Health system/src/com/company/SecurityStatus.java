package com.company;

public enum SecurityStatus {
    HIGH,
    MEDIUM,
    LOW
}
