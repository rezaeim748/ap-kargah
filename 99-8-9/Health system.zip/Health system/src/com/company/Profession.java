package com.company;

public enum Profession {
    CARDIOLOGIST,
    PULMONOLOGIST,
    NEUROLOGIST,
    ENDOCRINOLOGIST,
    GENERAL
}
