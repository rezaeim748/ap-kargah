package com.company;

public enum Illness {
    CARDIOVASCULAR,
    PULMONARY,
    NEURAL,
    ENDOCRIN0L,
    GENERAL
}
