package com.company;

public enum EducationalEvidence {
    DIPLOMA,
    BACHELOR,
    MA,
    DOCTORATE
}
