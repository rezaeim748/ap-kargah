package com.company;

public enum Gender {
    MALE,
    FEMALE
}
