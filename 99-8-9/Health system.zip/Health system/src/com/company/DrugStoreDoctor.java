package com.company;

/**
 * A class to make drug store doctor
 */
public class DrugStoreDoctor {
    private String name ;
    private String birthDate ;
    private Gender gender ;

    /**
     * Perform any initialization that is required
     * @param name The doctor name
     * @param birthDate The doctor birth date
     * @param gender The doctor gender
     */
    public DrugStoreDoctor(String name, String birthDate, Gender gender) {
        this.name = name;
        this.birthDate = birthDate;
        this.gender = gender;
    }


    // Getters and Setters

    public String getName() {
        return name;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public Gender getGender() {
        return gender;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    /**
     * Give drugs to the patient
     * @param patient The patient
     */
    public void giveDrugs (Patient patient){}


}
