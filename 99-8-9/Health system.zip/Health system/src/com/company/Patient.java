package com.company;

import java.util.ArrayList;

/**
 * A class to make patient
 */
public class Patient {
    private String name ;
    private String birthDate ;
    private Gender gender ;
    private boolean basicInsurance ;
    private boolean supplementaryInsurance ;
    private EducationalEvidence evidence ;
    private String job ;
    private String location ;
    private ArrayList<Doctor> reliableDoctors ;
    private MedicalRecord medicalRecord ;


    /**
     * Perform any initialization that is required
     * @param name The patient name
     * @param birthDate The patient birth date
     * @param gender The patient gender
     * @param basicInsurance The patient basic insurance
     * @param supplementaryInsurance The patient supplementary insurance
     * @param evidence The patient evidence
     * @param job The patient job
     * @param location The patient location
     * @param medicalRecord The patient medical record
     */
    public Patient(String name, String birthDate, Gender gender, boolean basicInsurance, boolean supplementaryInsurance, EducationalEvidence evidence, String job, String location, MedicalRecord medicalRecord) {
        this.name = name;
        this.birthDate = birthDate;
        this.gender = gender;
        this.basicInsurance = basicInsurance;
        this.supplementaryInsurance = supplementaryInsurance;
        this.evidence = evidence;
        this.job = job;
        this.location = location;
        reliableDoctors = new ArrayList<>() ;
        this.medicalRecord = medicalRecord ;
    }



    // Getters and Setters


    public String getName() {
        return name;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public Gender getGender() {
        return gender;
    }

    public boolean isBasicInsurance() {
        return basicInsurance;
    }

    public boolean isSupplementaryInsurance() {
        return supplementaryInsurance;
    }

    public EducationalEvidence getEvidence() {
        return evidence;
    }

    public String getJob() {
        return job;
    }

    public String getLocation() {
        return location;
    }

    public ArrayList<Doctor> getReliableDoctors() {
        return reliableDoctors;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public void setBasicInsurance(boolean basicInsurance) {
        this.basicInsurance = basicInsurance;
    }

    public void setSupplementaryInsurance(boolean supplementaryInsurance) {
        this.supplementaryInsurance = supplementaryInsurance;
    }

    public void setEvidence(EducationalEvidence evidence) {
        this.evidence = evidence;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setMedicalRecord(MedicalRecord medicalRecord) {
        this.medicalRecord = medicalRecord;
    }


    /**
     * Choose reliable doctor
     */
    public void chooseReliableDoctor (){}






}
