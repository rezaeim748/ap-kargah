package com.company;

/**
 * A class to save medical records
 */
public class MedicalRecord {
    private Illness illness ;
    private String explanation ;
    private String doctorOpinion ;
    private SecurityStatus securityStatus ;
    private String drug ;
    private String date ;
    private Doctor doctor ;

    /**
     * Perform any initialization that is required
     * @param illness The patient illness
     * @param explanation The patient explanation
     * @param doctorOpinion The patient doctor opinion
     * @param securityStatus The patient security status
     * @param drug The patient drugs
     * @param date The date
     * @param doctor The patient doctor
     */
    public MedicalRecord(Illness illness, String explanation, String doctorOpinion, SecurityStatus securityStatus, String drug, String date, Doctor doctor) {
        this.illness = illness;
        this.explanation = explanation;
        this.doctorOpinion = doctorOpinion;
        this.securityStatus = securityStatus;
        this.drug = drug;
        this.date = date;
        this.doctor = doctor;
    }



    // Getters and Setters

    public Illness getIllness() {
        return illness;
    }

    public String getExplanation() {
        return explanation;
    }

    public String getDoctorOpinion() {
        return doctorOpinion;
    }

    public SecurityStatus getSecurityStatus() {
        return securityStatus;
    }

    public String getDrug() {
        return drug;
    }

    public String getDate() {
        return date;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setIllness(Illness illness) {
        this.illness = illness;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    public void setDoctorOpinion(String doctorOpinion) {
        this.doctorOpinion = doctorOpinion;
    }

    public void setSecurityStatus(SecurityStatus securityStatus) {
        this.securityStatus = securityStatus;
    }

    public void setDrug(String drug) {
        this.drug = drug;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }
}
