package com.company;

/**
 * A class to make doctor
 */
public class Doctor {
    private String name ;
    private String birthDate ;
    private Gender gender ;
    private Profession profession ;

    /**
     * Perform any initialization that is required
     * @param name The doctor name
     * @param birthDate The doctor birth date
     * @param gender The doctor gender
     * @param profession The doctor profession
     */
    public Doctor(String name, String birthDate, Gender gender, Profession profession) {
        this.name = name;
        this.birthDate = birthDate;
        this.gender = gender;
        this.profession = profession;
    }



    // Getters and Setters

    public String getName() {
        return name;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public Gender getGender() {
        return gender;
    }

    public Profession getProfession() {
        return profession;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public void setProfession(Profession profession) {
        this.profession = profession;
    }

    /**
     * Choose doctor for patient
     * @param patient The patient
     */
    public void chooseDoctorForPatient (Patient patient){}



}
