package com.company;

import java.text.DecimalFormat;

public class Circle {

    private int radius ;

    public Circle (int radius){
        this.radius = radius ;
    }


    public int getRadius (){ return radius ; }

    public String calculatePerimeter (){
        return new DecimalFormat("##.##").format(2 * Math.PI * radius) ;
    }

    public String calculateArea (){
        return new DecimalFormat("##.##").format(Math.PI * Math.pow(radius, 2)) ;
    }

    public void draw (){
        System.out.print("Type : Circle, ") ;
        System.out.print("Perimeter: ") ;
        System.out.print(calculatePerimeter()) ;
        System.out.print(", Area: ");
        System.out.print(calculateArea()) ;
        System.out.println() ;
    }

    public boolean equals (Circle circle){
        if (circle.getRadius() == this.radius){
            return true ;
        }
        return false ;
    }

    public String toString (){
        return "Circle:: radius:" + radius ;
    }
}
