package com.company;

import java.util.ArrayList;

public class Rectangle {

    private ArrayList<Integer> sides ;

    public Rectangle (int a, int b, int c, int d){
        sides = new ArrayList<>() ;
        sides.add(a) ;
        sides.add(b) ;
        sides.add(c) ;
        sides.add(d) ;
    }


    public ArrayList<Integer> getSides (){ return sides ; }

    public boolean isSquare (){
        if (sides.get(0) == sides.get(1)){
            return true ;
        }
        return false ;
    }

    public int calculatePerimeter (){
        return (2 * (sides.get(0) + sides.get(1))) ;
    }

    public int calculateArea (){
        return (sides.get(0) * sides.get(1)) ;
    }

    public void draw (){
        System.out.print("Type : Rectangle, ") ;
        System.out.print("Perimeter: ") ;
        System.out.print(calculatePerimeter()) ;
        System.out.print(", Area: ");
        System.out.print(calculateArea()) ;
        System.out.println() ;
    }

    public boolean equals (Rectangle rectangle){
        if ((rectangle.getSides().get(0) == this.sides.get(0)) && (rectangle.getSides().get(1) == this.sides.get(1))){
            return true ;
        }
        return false ;
    }

    public String toString (){
        return ("Rectangle:: side1:" + sides.get(0) + ", side2:" + sides.get(1) + ", side3:" + sides.get(2) + ", side4:" + sides.get(3)) ;
    }


}
