package com.company;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class Triangle {

    private ArrayList<Integer> sides ;

    public Triangle (int a, int b, int c){
        sides = new ArrayList<>() ;
        sides.add(a) ;
        sides.add(b) ;
        sides.add(c) ;
    }

    public ArrayList<Integer> getSides (){ return sides ; }

    public boolean isEquilateral (){
        if ((sides.get(0) == sides.get(1)) && (sides.get(1) == sides.get(2))){
            return true ;
        }
        return false ;
    }

    public int calculatePerimeter (){
        return (sides.get(0) + sides.get(1) + sides.get(2)) ;
    }

    public String calculateArea (){
        double p = ((double) (sides.get(0) + sides.get(1) + sides.get(2))) / 2 ;
        double result = Math.pow(p * (p - sides.get(0)) * (p - sides.get(1)) * (p - sides.get(2)) , 0.5) ;
        return (new DecimalFormat("##.##").format(result)) ;
    }

    public void draw (){
        System.out.print("Type : Triangle, ") ;
        System.out.print("Perimeter: ") ;
        System.out.print(calculatePerimeter()) ;
        System.out.print(", Area: ");
        System.out.print(calculateArea()) ;
        System.out.println() ;
    }

    public boolean equals (Triangle triangle){
        if ((triangle.getSides().get(0) == this.sides.get(0)) && (triangle.getSides().get(1) == this.sides.get(1)) && (triangle.getSides().get(2) == this.sides.get(2))){
            return true ;
        }
        return false ;
    }

    public String toString (){
        return ("Triangle:: side1:" + sides.get(0) + ", side2:" + sides.get(1) + ", side3:" + sides.get(2)) ;
    }
}
