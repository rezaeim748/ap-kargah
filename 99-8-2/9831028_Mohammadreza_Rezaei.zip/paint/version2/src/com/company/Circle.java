package com.company;

import java.text.DecimalFormat;

public class Circle extends Shape {

    private int radius ;


    public Circle (int radius){
        super() ;
        this.radius = radius ;
    }




    public int getRadius (){ return radius ; }

    @Override
    public String calculatePerimeter() { return new DecimalFormat("##.##").format(2 * Math.PI * radius) ; }

    @Override
    public String calculateArea() {
        return new DecimalFormat("##.##").format(Math.PI * Math.pow(radius, 2)) ;
    }

    @Override
    public void draw() {
        System.out.print("Type : Circle, ") ;
        System.out.print("Perimeter: ") ;
        System.out.print(calculatePerimeter()) ;
        System.out.print(", Area: ");
        System.out.print(calculateArea()) ;
        System.out.println() ;
    }

    @Override
    public boolean equals(Shape shape) {
        Circle circle = (Circle) shape ;
        if (circle.getRadius() == this.radius){
            return true ;
        }
        return false ;
    }

    @Override
    public String toString() {
        return "Circle:: radius:" + radius ;
    }
}
