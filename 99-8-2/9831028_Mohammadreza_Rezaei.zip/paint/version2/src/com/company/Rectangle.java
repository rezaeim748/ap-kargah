package com.company;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Random;

public class Rectangle extends Polygon{

    public Rectangle (String... args){
        super(args) ;
    }





    public boolean isSquare (){
        if (getSides().get(0) == getSides().get(1)){
            return true ;
        }
        return false ;
    }



    @Override
    public ArrayList<Integer> getSides() {
        return super.getSides();
    }

    @Override
    public String calculatePerimeter() { return new DecimalFormat("##.##").format(2 * (getSides().get(0) + getSides().get(1))) ; }

    @Override
    public String  calculateArea() { return new DecimalFormat("##.##").format((getSides().get(0) * getSides().get(1))) ; }

    @Override
    public void draw() {
        System.out.print("Type : Rectangle, ") ;
        System.out.print("Perimeter: ") ;
        System.out.print(calculatePerimeter()) ;
        System.out.print(", Area: ");
        System.out.print(calculateArea()) ;
        System.out.println() ;
    }

    @Override
    public boolean equals(Shape shape) {
        Rectangle rectangle = (Rectangle) shape ;
        if ((rectangle.getSides().get(0) == this.getSides().get(0)) && (rectangle.getSides().get(1) == this.getSides().get(1))){
            return true ;
        }
        return false ;
    }

    @Override
    public String toString() {
        return ("Rectangle:: side1:" + getSides().get(0) + ", side2:" + getSides().get(1) + ", side3:" + getSides().get(2) + ", side4:" + getSides().get(3)) ;
    }
}
