package com.company;

public class Main {

    public static void main(String[] args) {



        Paint paint = new Paint() ;


        paint.addShape(new Circle(10)) ;
        paint.addShape(new Rectangle("2","3","2","3")) ;
        paint.addShape(new Triangle("2","3","4")) ;

        paint.drawAll() ;


    }
}
