package com.company;

import java.util.ArrayList;

public abstract class Polygon extends Shape {

    private ArrayList<Integer> sides ;

    public Polygon (String... args){
        sides = new ArrayList<>() ;
        for (String arg : args){
            sides.add(Integer.parseInt(arg)) ;
        }
    }




    public ArrayList<Integer> getSides (){ return sides ; }


}
