package com.company;

import java.text.DecimalFormat;
import java.util.ArrayList;


public class Triangle extends Polygon {


    public Triangle (String... args){
        super(args) ;
    }





    public boolean isEquilateral (){
        if ((getSides().get(0) == getSides().get(1)) && (getSides().get(1) == getSides().get(2))){
            return true ;
        }
        return false ;
    }

    @Override
    public ArrayList<Integer> getSides() {
        return super.getSides();
    }

    @Override
    public String calculatePerimeter() { return new DecimalFormat("##.##").format(getSides().get(0) + getSides().get(1) + getSides().get(2)) ; }

    @Override
    public String calculateArea() {
        double p = ((double) (getSides().get(0) + getSides().get(1) + getSides().get(2))) / 2 ;
        double result = Math.pow(p * (p - getSides().get(0)) * (p - getSides().get(1)) * (p - getSides().get(2)) , 0.5) ;
        return (new DecimalFormat("##.##").format(result)) ;
    }

    @Override
    public void draw() {
        System.out.print("Type : Triangle, ") ;
        System.out.print("Perimeter: ") ;
        System.out.print(calculatePerimeter()) ;
        System.out.print(", Area: ");
        System.out.print(calculateArea()) ;
        System.out.println() ;
    }

    @Override
    public boolean equals(Shape shape) {
        Triangle triangle = (Triangle) shape ;
        if ((triangle.getSides().get(0) == this.getSides().get(0)) && (triangle.getSides().get(1) == this.getSides().get(1)) && (triangle.getSides().get(2) == this.getSides().get(2))){
            return true ;
        }
        return false ;
    }

    @Override
    public String toString() {
        return ("Triangle:: side1:" + getSides().get(0) + ", side2:" + getSides().get(1) + ", side3:" + getSides().get(2)) ;
    }
}
