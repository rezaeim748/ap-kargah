package com.company;

public abstract class Shape {

    public Shape (){}



    public abstract String calculatePerimeter () ;

    public abstract String calculateArea () ;

    public abstract void draw () ;

    public abstract boolean equals (Shape shape) ;

    public abstract String toString () ;






}
